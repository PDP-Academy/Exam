
public class FilterMapping
{  }

public class Result
{
    public int Id { get; set; }
    public string Name { get; set; }
    public string Image { get; set; }
    public string Link { get; set; }
    public string Type { get; set; }
    public int Relevance { get; set; }
    public string Content { get; set; }
    public List<object> DataPoints { get; set; }
}

public class Root
{
    public string Sorting { get; set; }
    public FilterMapping FilterMapping { get; set; }
    public List<object> FilterOptions { get; set; }
    public List<object> ActiveFilterOptions { get; set; }
    public string Query { get; set; }
    public int TotalResults { get; set; }
    public int Limit { get; set; }
    public int Offset { get; set; }
    public List<SearchResult> searchResults { get; set; }
    public long Expires { get; set; }
    public bool IsStale { get; set; }
}

public class SearchResult
{
    public string Name { get; set; }
    public string Type { get; set; }
    public int TotalResults { get; set; }
    public int TotalResultsVariants { get; set; }
    public List<Result> Results { get; set; }
}

