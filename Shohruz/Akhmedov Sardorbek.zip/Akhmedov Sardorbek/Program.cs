﻿using System;
using System.Text.Json;
using Telegram.Bot;
using Telegram.Bot.Types.Enums;
using Telegram.Bot.Polling;
using Telegram.Bot.Types;

Console.Clear();
Console.ForegroundColor = ConsoleColor.Cyan;


string url = "https://api.spoonacular.com/food/search?apiKey=7c997507f82842669116673e8ce67fdf";

string TOKEN = @"5674695715:AAEGpPEyu_tUbeJp_C4slf89laNWGq9PQM0";

var botClient = new TelegramBotClient(TOKEN);

using var cts = new CancellationTokenSource();

var receiverOptions = new ReceiverOptions()
{
    AllowedUpdates = Array.Empty<UpdateType>()
};

botClient.StartReceiving(
    updateHandler: UpdateHandleAsync,
    pollingErrorHandler: PollingErrorHandle,
    receiverOptions: receiverOptions,
    cancellationToken: cts.Token );


var me = await botClient.GetMeAsync();
Console.WriteLine($"Bot ishga tushdi! \nBot Id: {me.Id}  || Bot name: {me.FirstName} ");
Console.ReadLine();

cts.Cancel();

async Task UpdateHandleAsync(ITelegramBotClient botClient, Update update, CancellationToken cancellationToken)
{
    if (update.Message is not { } message)
        return;

    if (message.Text is not { } messageText)
        return;

    var chatId = message.Chat.Id;

    var me = await botClient.GetMeAsync();
    Console.WriteLine($"Bot ishga tushdi!  \nBot name: {me.FirstName}  ||  Message: {messageText}  ");

    Message sentMessage = await botClient.SendTextMessageAsync(
        chatId: chatId,
        text: $"Siz yozgan habar:  {messageText}",
        cancellationToken: cancellationToken);
}

Task PollingErrorHandle(ITelegramBotClient botClient, Exception exception, CancellationToken cancellationToken)
{
    throw new NotImplementedException();
}














// === < Task_3 > ===: 

/*
int[] arr = new int[] { 1, 4, 4}; 

Console.WriteLine( MinSubArrayLen(4 , arr) );

static int MinSubArrayLen(int target, int[] arr)
{
    int i = 0, result = arr.Length + 1;

    for (int j = 0; j < arr.Length; j++)
    {
        target -= arr[j];
        while (target <= 0)
        {
            result = Math.Min(result, j - i + 1);
            target += arr[i++];
        }
    }
    return result % (arr.Length + 1);
}
*/

// === < Task_2 > ===:

/*
string num1 = "11", num2 = "123";

Console.WriteLine( AddStrings(num1, num2) );

static string AddStrings(string num1, string num2)
{
    num1 = ReverseString(num1);
    num2 = ReverseString(num2);

    num1 = new StringBuilder(num1).ToString();
    num2 = new StringBuilder(num2).ToString();

    string result = "";
    int carry = 0;

    for (int i = 0; i < num1.Length || i < num2.Length; i++)
    {
        int c1 = 0;
        int c2 = 0;
        if (i < num1.Length)
        {
            c1 = (int)num1[i] - '0';
        }

        if (i < num2.Length)
        {
            c2 = (int)num2[i] - '0';
        }

        int sum = c1 + c2 + carry;
        int digit = sum % 10;
        carry = sum / 10;
        result = digit + result;
    }

    if (carry != 0)
        result = carry + result;

    return result;
}

static string ReverseString(string str)
{
     string newStr = "";
    for (int i = str.Length -1; i >= 0; i--)
    {
        newStr += str[i];      
    }
    return newStr;
}

*/


// === < Task_1 > ===:

/*
Console.WriteLine( To16(10) );

Console.WriteLine(26 & 15);

static string To16(int num)
{
    if (num == 0)
        return "0";

    char[] hex = new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };

    StringBuilder str = new StringBuilder();
    int count = 0;
    while (count < 8 && num != 0)
    {
        str.Append(hex[num & 15]);
        num = num >> 4;
        count++;
    }
    string newStr = "";
    for (int i = str.Length -1; i >= 0; i--)
    {
        newStr += str[i];      
    }
    return newStr.ToString();
}
*/





