﻿using Exam3App.Brokers;
using Telegram.Bot.Exceptions;
using Telegram.Bot.Polling;
using Telegram.Bot.Types.Enums;
using Telegram.Bot.Types;
using Telegram.Bot;

namespace Exam3App
{
    public class Program
    {
        static void Main(string[] args)
        {
           ApiBroker broker = new ApiBroker();
           var listPhoto=  broker.GetPhotoFoodsListAsync();

            var botClient = new TelegramBotClient("5583816230:AAGayIl1hyLFWb6SGjrFA5YkjibWTd-9OTQ");

            using var cts = new CancellationTokenSource();

            
            var receiverOptions = new ReceiverOptions
            {
                AllowedUpdates = Array.Empty<UpdateType>() 
            };
            botClient.StartReceiving(
                updateHandler: HandleUpdateAsync,
                pollingErrorHandler: HandlePollingErrorAsync,
                receiverOptions: receiverOptions,
                cancellationToken: cts.Token
            );

            
            Console.ReadLine();

           
            cts.Cancel();

            async Task HandleUpdateAsync(ITelegramBotClient botClient, Update update, CancellationToken cancellationToken)
            {

                if (update.Message is not { } message)
                    return;

                if (message.Text is not { } messageText)
                    return;

                var chatId = message.Chat.Id;



                for (int i = 0; i < 10; i++)
                {


                    Message message2 = await botClient.SendPhotoAsync(
        chatId: chatId,
      photo:
        
        cancellationToken: cancellationToken);
                }
            }

            Task HandlePollingErrorAsync(ITelegramBotClient botClient, Exception exception, CancellationToken cancellationToken)
            {
                var ErrorMessage = exception switch
                {
                    ApiRequestException apiRequestException
                        => $"Telegram API Error:\n[{apiRequestException.ErrorCode}]\n{apiRequestException.Message}",
                    _ => exception.ToString()
                };

                Console.WriteLine(ErrorMessage);
                return Task.CompletedTask;
            }















        }
        




    }
}