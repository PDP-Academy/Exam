﻿using Exam3App.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.WebSockets;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace Exam3App.Brokers;

public  class ApiBroker 
{
    private const string BASE_URL = "https://api.spoonacular.com/food/search?apiKey=2133c637c19347e38bfeaae6d313101a";
    private async Task<string> GetContentAsync(string url)
    {
        using var client = new HttpClient();
        return await client.GetStringAsync(url);
    }

    public void Dispose()
    { }


    //Foods  oybektini list ko'rinishida qaytaradi 
    public async Task<IList<Food>> GetPhotoFoodsListAsync()
    {

        var content = await GetContentAsync(BASE_URL);

        return JsonSerializer.Deserialize<IList<Food>>(content);

    }
}
