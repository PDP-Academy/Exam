﻿using System.Text;

int dec10 = int.Parse(Console.ReadLine());


if (dec10 == 0)
    Console.WriteLine("0");

string hex16 = "0123456789abcdef";

StringBuilder strbuild = new StringBuilder();

while (dec10 != 0 && strbuild.Length < 8)
{
    strbuild.Append(hex16[dec10 & 15]);
    dec10 >>= 4;
}

string str =  new string(strbuild.ToString().ToCharArray().Reverse().ToArray());


Console.WriteLine(str);