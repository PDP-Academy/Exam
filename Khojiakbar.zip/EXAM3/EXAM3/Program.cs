﻿int target = 14;                                  //11
int[] nums = {4, 5, 2, 3, 3, 1, 7, 3, 4, 9};    //{1, 1, 1, 1, 1, 1, 1, 1, 1, 11}

int result = int.MaxValue;
int summa = 0;
int index = 0;
for (int i = 0; i < nums.Length; i++)
{
    summa += nums[i];

    while (summa >= target)
    {
        result = Math.Min(result, i - index + 1); // 1
        
        summa -= nums[index++]; // 11
    }
}

result = result == int.MaxValue ? 0 : result; // 1

Console.WriteLine(result);
