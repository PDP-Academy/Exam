﻿using System.Text;

string num1 = "450";
string num2 = "220";

StringBuilder str = new StringBuilder();
int num1Index = num1.Length - 1, num2Index = num2.Length - 1;
while (num1Index >= 0 && num2Index >= 0)
{
    int value = num1[num1Index--] - '0' + num2[num2Index--] - '0';

    int digit = value % 10;
    

    str.Append(digit);
}

while (num1Index >= 0)
{
    int value = num1[num1Index--] - '0';
    int digit = value % 10;
    
    str.Append(digit);
}

while (num2Index >= 0)
{
    int value = num2[num2Index--] - '0';
    int digit = value % 10;
    
    str.Append(digit);
}


string Answer =  new string(str.ToString().Reverse().ToArray());


Console.WriteLine(Answer);