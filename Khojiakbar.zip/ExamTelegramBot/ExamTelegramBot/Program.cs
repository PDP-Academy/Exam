﻿using Telegram.Bot;
using Telegram.Bot.Exceptions;
using Telegram.Bot.Polling;
using Telegram.Bot.Types;
using Telegram.Bot.Types.Enums;
using Telegram.Bot.Types.ReplyMarkups;
using System.IO;


    var Client = new TelegramBotClient("5555357339:AAH-V2eLJe7hcCZU0xE-n76P9vMyAJv1TBQ");

    using var CancelToken = new CancellationTokenSource();

    var receiverOptions = new ReceiverOptions
    {
        AllowedUpdates = Array.Empty<UpdateType>()
    };
    Client.StartReceiving(
        updateHandler: HandleUpdateAsync,
        pollingErrorHandler: HandlePollingErrorAsync,
        receiverOptions: receiverOptions,
        cancellationToken: CancelToken.Token
    );
    var user = await Client.GetMeAsync();
    Console.WriteLine($"Bot is started @{user.Username}");
    Console.ReadLine();
    CancelToken.Cancel();


async Task HandleUpdateAsync(ITelegramBotClient Client, Update update, CancellationToken cancellationToken)
{
    if (update.Message is { })
    {
        string path = update.Message.Chat.Id.ToString() + ".txt";
        Beginning(Client, update, cancellationToken, path);
    }
}

async Task Beginning(ITelegramBotClient botClient, Update update, CancellationToken cancellationToken, string path)
{
    if (update.Message.Contact is { })
    {
        string info;
        using (StreamReader sr = new StreamReader(path))
        {
            info = sr.ReadToEnd();
        }
        using (StreamWriter sw = new StreamWriter(path))
        {
            sw.WriteLine(info);
            sw.WriteLine($"Contact: {update.Message.Contact.PhoneNumber}");
        }
        await botClient.SendTextMessageAsync(
        chatId: update.Message.Chat.Id,
        text: " Share your location ",
        replyMarkup: new ReplyKeyboardMarkup(
            new KeyboardButton(" Location ")
            {
                RequestLocation = true
            }
        )
        {
            ResizeKeyboard = true
        },
        cancellationToken: cancellationToken);
    }
    if (update.Message.Text is { })
    {
        if (update.Message.Text == "/start")
            await botClient.SendTextMessageAsync(
                chatId: update.Message.Chat.Id,
                text: " Input your name ",
                cancellationToken: cancellationToken
            );
        else
        {
            FileInfo fileInfo = new FileInfo(path);
            if (!fileInfo.Exists)
            {
                using (StreamWriter streamWriter = new StreamWriter(path))
                {
                    streamWriter.WriteLineAsync($"Name: {update.Message.Text}");
                }
                await botClient.SendTextMessageAsync(
                chatId: update.Message.Chat.Id,
                text: " Share your contact info ",
                replyMarkup: new ReplyKeyboardMarkup(
                    new KeyboardButton(" Contact ")
                    {
                        RequestContact = true
                    }
                )
                {
                    ResizeKeyboard = true
                },
                cancellationToken: cancellationToken);
            }
        }
    }
    if (update.Message.Location is { })
    {
        string str;
        using (StreamReader streamReader = new StreamReader(path))
        {
            str = streamReader.ReadToEnd();
        }
        using (StreamWriter streamWriter = new StreamWriter(path))
        {
            if (str != null)
                streamWriter.WriteLine(str);
            streamWriter.WriteLine($"Location: {update.Message.Location.Latitude}/{update.Message.Location.LivePeriod}");
        }
        Ordering(botClient, update, cancellationToken);
    }

}
async Task Ordering(ITelegramBotClient botClient, Update update, CancellationToken cancellationToken)
{
    string ApiKey = "?apiKey=a73ff58f28c04dbba14ac399228670ce";
    HttpClient httpClient = new HttpClient();
    if (update.Message is { })
        await botClient.SendTextMessageAsync(
            chatId: update.Message.Chat.Id,
            cancellationToken: cancellationToken,
            text: " Enter your order "

        );
}
Task HandlePollingErrorAsync(ITelegramBotClient botClient, Exception exception, CancellationToken cancellationToken)
{
    var ErrorMessage = exception switch
    {
        ApiRequestException apiRequestException
            => $"Telegram API Error:\n[{apiRequestException.ErrorCode}]\n{apiRequestException.Message}",
        _ => exception.ToString()
    };

    Console.WriteLine(ErrorMessage);
    return Task.CompletedTask;
}






















class User
{
    public string Name { get; set; }
    public string Numbers { get; set; }
    public string Location { get; set; }
}



