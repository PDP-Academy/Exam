﻿namespace _1_masala
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] array = new int[] { 2,1,1,1,1,476,86,43,23,456,1234,4321,2345};

            int target = 8765,minLength = int.MaxValue;
            int count = 0;

            for (int i = 0; i < array.Length; i++)
            {
                int sum = 0, k = 0;
                for (int j = i; j < array.Length; j++)
                {
                    sum += array[j];
                    k++;
                    if (sum >= target)
                    {
                        break;
                    }
                }
                Console.WriteLine(sum);
                if (k < minLength && sum >= target)
                {
                    count++;
                    minLength = k;
                }
            }
            Console.WriteLine((count == 0)?0:minLength);
        }
    }
}