﻿
using Telegram.Bot;
using Telegram.Bot.Types.ReplyMarkups;
using TelegramBotFood.Brokers.ApiaBroker;

namespace TelegramBotFood.Views.ApiViews
{
    public class ResultsView
    {
        public async Task StartCommandAsync(
        ITelegramBotClient botClient,
        long chatId,
        int messageId)
        {
            await botClient.SendTextMessageAsync(
                chatId: chatId,
                text: "Quyidagilardan birini tanlang",
                replyMarkup: GenerateButtons());
        }

        public async Task SendMesssageRequestDataAsync(
        ITelegramBotClient botClient,
        long chatId)
        {
            await botClient.SendTextMessageAsync(
                chatId: chatId,
                text: "Shaxsiy ma'lumotlaringizni kiriting : (ism,raqam,locatsiya)");
                
        }

        static int maxButtonsLength = 3;

        public static InlineKeyboardMarkup GenerateButtons()
        {
            var datas = GetResultService().RetrieveAllResultsAsync().Result;
            var buttons = new List<List<InlineKeyboardButton>>();
            int index = 0;
            if (datas is not null)
            {
                for (; index < datas.Count; index++)
                {
                    if (index % maxButtonsLength == 0)
                        buttons.Add(new List<InlineKeyboardButton>());

                    buttons[index / maxButtonsLength].Add(
                        new InlineKeyboardButton(datas[index].Name)
                        {
                            CallbackData = datas[index].Name,
                        }
                    );
                }
            }
            

            return new InlineKeyboardMarkup(buttons);
        }

        static IResultService GetResultService()
        {
            IApiBroker broker = new ApiBroker();

            return new ResultService(broker);
        }
    }
}
