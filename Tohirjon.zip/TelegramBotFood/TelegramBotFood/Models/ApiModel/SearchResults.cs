﻿
using System.Text.Json.Serialization;

namespace TelegramBotFood.Models.ApiModel
{
    public class SearchResults
    {
        [JsonPropertyName("Results")]

        public List<Results> Results { get; set; }
    }
}
