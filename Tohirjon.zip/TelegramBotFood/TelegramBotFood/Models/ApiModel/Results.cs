﻿
using System.Text.Json.Serialization;

namespace TelegramBotFood.Models.ApiModel
{
    public class Results
    {
        [JsonPropertyName("name")]
        public string Name { get; set; }

        [JsonPropertyName("image")]

        public string Image { get; set; }
    }
}
