﻿
using System.Text.Json.Serialization;

namespace TelegramBotFood.Models.ApiModel
{
    public class Food
    {
        [JsonPropertyName("SearchResults")]

        public List<SearchResults> SearchResults { get; set; }
    }
}
