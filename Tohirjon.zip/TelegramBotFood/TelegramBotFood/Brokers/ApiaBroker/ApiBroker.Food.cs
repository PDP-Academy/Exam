﻿
using System.Text;
using TelegramBotFood.Brokers.ApiaBroker.Exceptions;
using TelegramBotFood.Models.ApiModel;

namespace TelegramBotFood.Brokers.ApiaBroker
{
    public partial class ApiBroker
    {
        private const string baseUrl = @"";

        public async ValueTask<List<Results>> GetFoodCollectionAsync()
        {
            
            var food = await this.GetAsync<Food>(baseUrl);

            return food.SearchResults[0].Results;
        }
    }
}
