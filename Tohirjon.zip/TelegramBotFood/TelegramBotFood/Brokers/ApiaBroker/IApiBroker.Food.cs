﻿
using TelegramBotFood.Models.ApiModel;

namespace TelegramBotFood.Brokers.ApiaBroker
{
    public partial interface IApiBroker
    {
        public ValueTask<List<Results>> GetFoodCollectionAsync();
    }
}
