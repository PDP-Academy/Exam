﻿
using System.Text.Json;

namespace TelegramBotFood.Brokers.ApiaBroker
{
    public partial class ApiBroker : IApiBroker
    {
        private readonly HttpClient httpClient;

        public ApiBroker()
        {
            httpClient = new HttpClient();

            httpClient.DefaultRequestHeaders.Add("User-Agent", "ConsoleApp");
        }

        public async ValueTask<T> GetAsync<T>(string relativeUrl)
        {
            var response = await httpClient.GetAsync(relativeUrl);
            var content = await response.Content.ReadAsStringAsync();


            return JsonSerializer.Deserialize<T>(content);
        }
    }
}
