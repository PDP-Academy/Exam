﻿
namespace TelegramBotFood.Brokers.ApiaBroker
{
    public partial interface IApiBroker
    {
    }
}
