﻿
using TelegramBotFood.Brokers.ApiaBroker;
using TelegramBotFood.Models.ApiModel;


public partial class ResultService : IResultService
{
    private readonly IApiBroker apiBroker;

    public ResultService(IApiBroker apiBroker)
    {
        this.apiBroker = apiBroker;
    }

    public ValueTask<List<Results>> RetrieveAllResultsAsync() => apiBroker.GetFoodCollectionAsync();

    
}