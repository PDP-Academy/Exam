﻿using TelegramBotFood.Models.ApiModel;

public interface IResultService
{
    ValueTask<List<Results>> RetrieveAllResultsAsync();

}