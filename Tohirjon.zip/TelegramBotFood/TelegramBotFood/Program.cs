﻿using Telegram.Bot.Exceptions;
using Telegram.Bot.Polling;
using Telegram.Bot.Types.Enums;
using Telegram.Bot.Types;
using Telegram.Bot;
using TelegramBotFood.Brokers.ApiaBroker;
using TelegramBotFood.Views.ApiViews;

namespace TelegramBotFood
{
    public class Program
    {
        private const string TOKEN = "";

        static ResultsView resultsView = new ResultsView(); 

        static void Main(string[] args)
        {
            try
            {
                using var cts = new CancellationTokenSource();
                var botClient = new TelegramBotClient(TOKEN);

                var receiverOptions = new ReceiverOptions
                {
                    AllowedUpdates = Array.Empty<UpdateType>()
                };

                botClient.StartReceiving(
                    updateHandler: HandleUpdateAsync,
                    pollingErrorHandler: HandlePollingErrorAsync,
                    receiverOptions: receiverOptions,
                    cancellationToken: cts.Token);

                Console.WriteLine("Bot started working");

                Console.ReadLine();
            }
            catch { }
        }

        static async Task HandleUpdateAsync(
        ITelegramBotClient botClient,
        Update update,
        CancellationToken cancellationToken)
        {
            if(update.Message != null)
            {
                if(update.Message.Text == "/start")
                {
                    resultsView.SendMesssageRequestDataAsync(botClient, update.Message.Chat.Id);       
                }
                else if(update.Message.Text != "/start")
                {
                    resultsView.StartCommandAsync(botClient, update.Message.Chat.Id, update.Message.MessageId);
                }
            }
           

            #region OnMessageReceived

            async Task OnMessageReceived()
            {
                var mainView = new MainView(GetPrayerTimeService());
                var message = update.Message;


                if (message.Type != MessageType.Text)
                    return;

                if (message.Text == "/start")
                {
                    await mainView.StartCommandAsync(botClient, message.Chat.Id, message.MessageId);
                }
            }


            
        }
}