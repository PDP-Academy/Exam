﻿namespace _2_misol
{
    public class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine(AddTwoNum("556", "77"));       
        }
        static string AddTwoNum(string num1, string num2)
        {
            string result = "";
            int last1, last2, remaind, butun = 0;

            while (num1.Length > 0 || num2.Length > 0)
            {
                
                if (num1.Length == 0)
                {
                    last1 = 0;
                    last2 = num2[num2.Length - 1] - '0';
                    num2 = num2.Remove(num2.Length - 1);
                    remaind = (last1 + last2 + butun) % 10;
                    result = remaind + result;

                }
                else if(num2.Length == 0)
                {
                    last1 = num1[num1.Length - 1] - '0';
                    num1 = num1.Remove(num1.Length - 1);
                    last2 = 0;
                    remaind = (last1 + last2 + butun) % 10;
                    result = remaind + result;
                }
                else
                {
                    last1 = num1[num1.Length - 1] - '0';
                    last2 = num2[num2.Length - 1] - '0';
                    num1 = num1.Remove(num1.Length - 1);
                    num2 = num2.Remove(num2.Length - 1);
                    
                    remaind = (last1 + last2 + butun) % 10;
                    butun = (last1 + last2) / 10;
                    result = remaind + result;
                }
                
                
            }
            return result;
        }
    }
}