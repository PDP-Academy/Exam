﻿namespace Imtihon3_misol
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] num = { 1, 2, 3, 4 };
            Console.WriteLine(SubArray(num,4));
        }
        public static int SubArray(int[] nums, int target)
        {
            int L = 0;
            int R = 0;

            int min = int.MaxValue;

            int sum = 0;

            while (L < nums.Length && R < nums.Length)
            {
                if (sum < target)
                    sum += nums[L++];

                else if (sum == target)
                {
                    min = Math.Min(min, L - R);
                    sum += nums[L++];
                    sum -= nums[R++];
                }
                else
                    sum -= nums[R++];

            }
            while (R < nums.Length && sum >= target)
            {
                if (sum == target)
                {
                    min = Math.Min(min, L - R);
                    break;
                }
                else
                    sum -= nums[R++];
            }

            if (min == int.MaxValue)
                return 0;
            return min;
        }
    }
}