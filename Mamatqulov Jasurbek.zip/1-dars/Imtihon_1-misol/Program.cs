﻿public class Program
{
    private static void Main(string[] args)
    {
        int a = int.Parse(Console.ReadLine());
        Console.WriteLine(DecToHex(a));
        Main(args);
    }
    private static string DecToHex(int num)
    {
  
        int n = 1;
        long b = a;
        while (b > 15)
        {
            b /= 16;
            n++;
        }
        string[] hex = new string[n];
        int i = 0, j = n - 1;
        do
        {
            if (a % 16 == 10) hex[i] = "a";
            else if (a % 16 == 11) hex[i] = "b";
            else if (a % 16 == 12) hex[i] = "c";
            else if (a % 16 == 13) hex[i] = "d";
            else if (a % 16 == 14) hex[i] = "e";
            else if (a % 16 == 15) hex[i] = "f";
            else hex[i] = (a % 16).ToString();
            a /= 16;
            i++;
        }
        while ((a * 16) > 15);
        string[] r = new string[n];
        for (i = 0; i < n; i++)
        {
            r[i] = hex[j];
            j--;
        }
        string res = string.Concat(r);
        return res;
        
    }
}
