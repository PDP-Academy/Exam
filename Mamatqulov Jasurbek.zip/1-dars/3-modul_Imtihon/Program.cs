﻿using Newtonsoft.Json;
using System.Text.Json.Serialization;
using Telegram.Bot;
using Telegram.Bot.Exceptions;
using Telegram.Bot.Extensions.Polling;
using Telegram.Bot.Polling;

using Telegram.Bot.Types;
using Telegram.Bot.Types.Enums;
using Telegram.Bot.Types.ReplyMarkups;
using ReceiverOptions = Telegram.Bot.Polling.ReceiverOptions;

namespace _3_modul_Imtihon
{
    public class Program
    {
        static async Task Main(string[] args)
        {
            TelegramBotClient client = new TelegramBotClient("5661071702:AAH814Csjsofl1Dq3GqweiVhfSEK3E7CFtg");
            using var cts = new CancellationTokenSource();

            var receiverOptions = new ReceiverOptions
            {
                AllowedUpdates = Array.Empty<UpdateType>()
            };

            client.StartReceiving(
                updateHandler: HandleUpdateAsync,
                pollingErrorHandler: HandlePollingErrorAsync,
                receiverOptions: receiverOptions,
                cancellationToken: cts.Token
            );


            Console.WriteLine("Bot ishga tushdi.....");

            Console.ReadLine();

            cts.Cancel();
        }
        static  async Task HandleUpdateAsync(
            ITelegramBotClient client,
            Update update,
            CancellationToken cancellationToken)
        {

            if(update.Message != null)
            {
                if (update.Message.Text == "/start")
                {
                    ReplyKeyboardMarkup markup = new ReplyKeyboardMarkup(KeyboardButton.WithRequestContact("Contact yuborish"));
                    markup.ResizeKeyboard = true;
                    await client.SendTextMessageAsync(
                            chatId: update.Message.Chat.Id,
                            text: "Contact",
                            replyMarkup: markup
                    );
                }
            }
            else
            {
                return;
            }
            static InlineKeyboardMarkup GetMarkup()
            {
                InlineKeyboardButton[] buttons = new InlineKeyboardButton[]
                   {
                        new InlineKeyboardButton("A")
                        {
                            CallbackData = "A"
                        },
                        new InlineKeyboardButton("B")
                        {
                            CallbackData = "B"
                        },
                   };

                InlineKeyboardMarkup markup =
                    new InlineKeyboardMarkup(buttons);
                return markup;
            }
            static async Foods GetFoodObjet()
            {
                string url = "https://api.spoonacular.com/food/search?apiKey=576027820de54a8493d3fb31f042fc22";
                HttpClient httpClient = new HttpClient();
                httpClient.BaseAddress = new Uri(url);
                var response = await httpClient.GetAsync(url);
                var content = await response.Content.ReadAsStringAsync();
                var deserilize = JsonConvert.DeserializeObject<Foods>(content);
                return deserilize;
            }
        }
        
        #region Error
        static Task HandlePollingErrorAsync(
            ITelegramBotClient client,
            Exception exception,
            CancellationToken cancellationToken)
                {
                    var ErrorMessage = exception switch
                    {
                        ApiRequestException apiRequestException
                            => $"Telegram API Error:\n[{apiRequestException.ErrorCode}]\n{apiRequestException.Message}",
                        _ => exception.ToString()
                    };

                    Console.WriteLine(ErrorMessage);
                    return Task.CompletedTask;
                }
        #endregion 
    }
}