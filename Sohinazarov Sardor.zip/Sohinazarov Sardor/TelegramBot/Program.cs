﻿using System;
using Telegram.Bot;
using Telegram.Bot.Exceptions;
using Telegram.Bot.Polling;
using Telegram.Bot.Types;
using Telegram.Bot.Types.Enums;
using Telegram.Bot.Types.ReplyMarkups;


var botClient = new TelegramBotClient("5750672831:AAEFBsYh2oHfIH8OSP7g_795exkAHPaTqog");

using var cts = new CancellationTokenSource();

var receiverOptions = new ReceiverOptions
{
    AllowedUpdates = Array.Empty<UpdateType>() // receive all update types
};

botClient.StartReceiving(
    updateHandler: HandleUpdateAsync,
    pollingErrorHandler: HandlePollingErrorAsync,
    receiverOptions: receiverOptions,
    cancellationToken: cts.Token
);

var me = await botClient.GetMeAsync();

Console.WriteLine($"Start listening for @{me.Username}");
Console.ReadLine();

// Send cancellation request to stop bot
cts.Cancel();

async Task HandleUpdateAsync(ITelegramBotClient botClient, Update update, CancellationToken cancellationToken)
{
    // Only process Message updates: https://core.telegram.org/bots/api#message
    if (update.Message is not { } message)
        return;
    // Only process text messages
    if (message.Text is not { } messageText)
        return;

    var chatId = message.Chat.Id;

    Console.WriteLine($"Qabul qilindi '{messageText}' message in chat {chatId}.");


    if(message.Text == "/start")
        {
            await botClient.SendTextMessageAsync(
                chatId:chatId,
                text:$"Assalomu alaykum ,qalesiz {message.Chat.FirstName}!",
                replyToMessageId:message.MessageId,
                cancellationToken:cancellationToken
            );


        }
    else if(message.Text == "video"){

        message = await botClient.SendVideoAsync(
        chatId: chatId,
        video: "https://player.vimeo.com/external/357941044.sd.mp4?s=4b58cdf2377615be10826c0e4f722c1990d8ac44&profile_id=164&oauth2_token_id=57447761\ns=8cd2af1ec08f7ce121a5a6a09c78c05237943524&profile_id=164&oauth2_token_id=57447761",
        //thumb: "https://raw.githubusercontent.com/TelegramBots/book/master/src/2/docs/thumb-clock.jpg",
        supportsStreaming: true,
        cancellationToken: cancellationToken);

        message = await botClient.SendStickerAsync(
        chatId:  chatId,
        sticker: "https://github.com/TelegramBots/book/raw/master/src/docs/sticker-dali.webp",
        cancellationToken: cancellationToken);

        message = await botClient.SendTextMessageAsync(
        chatId : chatId,
        text : "<b>Sohinazarov Sardor</b>",
        parseMode: ParseMode.Html,
        disableNotification: true,
        replyToMessageId: update.Message.MessageId,
        replyMarkup:new InlineKeyboardMarkup(
            InlineKeyboardButton.WithUrl(
                "Bizni Kanal",
                "https://t.me/SardorSohinazarov"
            )
        ),
        cancellationToken:cancellationToken);

        message = await botClient.SendAnimationAsync(
        chatId: chatId,
        animation: "https://raw.githubusercontent.com/TelegramBots/book/master/src/docs/video-waves.mp4",
        caption: "Waves",
        cancellationToken: cancellationToken);

        message = await botClient.SendPollAsync(
        chatId: chatId,
        question: "Did you ever hear the tragedy of Darth Plagueis The Wise?",
        options: new []
        {
            "Yes for the hundredth time!",
            "No, who`s that?"
        },
        cancellationToken: cancellationToken);

        message = await botClient.SendContactAsync(
        chatId: chatId,
        phoneNumber: "+1234567890",
        firstName: "Han",
        vCard: "BEGIN:VCARD\n" +
            "VERSION:3.0\n" +
            "N:Solo;Han\n" +
            "ORG:Scruffy-looking nerf herder\n" +
            "TEL;TYPE=voice,work,pref:+1234567890\n" +
            "EMAIL:hansolo@mfalcon.com\n" +
            "END:VCARD",
        cancellationToken: cancellationToken);

        message = await botClient.SendVenueAsync(
        chatId: chatId,
        latitude: 50.0840172f,
        longitude: 14.418288f,
        title: "Man Hanging out",
        address: "Husova, 110 00 Staré Město, Czechia",
        cancellationToken: cancellationToken);

        message = await botClient.SendLocationAsync(
        chatId: chatId,
        latitude: 33.747252f,
        longitude: -112.633853f,
        cancellationToken: cancellationToken);
    }
}


    // Echo received message text

Task HandlePollingErrorAsync(ITelegramBotClient botClient, Exception exception, CancellationToken cancellationToken)
{
    var ErrorMessage = exception switch
    {
        ApiRequestException apiRequestException
            => $"Telegram API Error:\n[{apiRequestException.ErrorCode}]\n{apiRequestException.Message}",
        _ => exception.ToString()
    };

    Console.WriteLine(ErrorMessage);
    return Task.CompletedTask;
}
